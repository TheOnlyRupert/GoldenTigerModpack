`toolstation.png` from [TinkersConstruct][1] distributed under [CC.3][2]


[1]: https://github.com/SlimeKnights/TinkersConstruct/blob/ad0a7e67fd839b451ac5e574989af9fb00915e4a/resources/assets/tinker/textures/gui/toolstation.png
[2]: http://creativecommons.org/licenses/by/3.0/