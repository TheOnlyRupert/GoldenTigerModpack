# Circuit Board

![Needs more gold.](oredict:oc:materialCircuitBoard)

Intermediate crafting item made from [raw circuit boards](rawCircuitBoard.md) and used to make [printed circuit boards](printedCircuitBoard.md).
