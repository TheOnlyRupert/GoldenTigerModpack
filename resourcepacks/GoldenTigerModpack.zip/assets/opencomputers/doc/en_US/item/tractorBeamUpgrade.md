# Tractor Beam

![Beam me up.](oredict:oc:tractorBeamUpgrade)

The tractor beam upgrade allows devices to pick up items in a three block radius around them. This can be highly useful when using [robots](../block/robot.md) in tree or other farms, or when having them use tools that break multiple blocks around them (such as Tinker's Construct tools). Each operation will try to suck a single item stack in range and consume some energy.
