# World Sensor Card

![To boldly go...](oredict:oc:worldSensorCard)

The world sensor card allows reading of atmospheric information as well as gravity on different planets added by Galacticraft. This can be useful for [robots](../block/robot.md) or [drones](drone.md) operating in space.
