# Leash Upgrade

![-redacted- ~ Vexatos 2015](oredict:oc:leashUpgrade)

The Leash upgrade allows putting animals on a leash, bound to the entity that hosts the device the component is used by, for example [drones](drone.md). Using this upgrade, multiple animals can be leashed at the same time, which makes this quite useful for moving herds.
