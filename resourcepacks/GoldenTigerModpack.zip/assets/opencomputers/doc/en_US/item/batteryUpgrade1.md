# Battery Ugrade

![Made of Metal.](oredict:oc:batteryUpgrade1)

This upgrade increases the internal energy buffer of devices, such as [robots](../block/robot.md) and [tablets](tablet.md), allowing them to operate longer without having to return to a [charger](../block/charger.md). Higher tier battery upgrades can store more energy. 
